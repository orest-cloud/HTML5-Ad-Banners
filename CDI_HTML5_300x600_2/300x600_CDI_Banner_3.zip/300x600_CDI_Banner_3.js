(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [
		{name:"300x600_CDI_Banner_3_atlas_", frames: [[0,0,54,538],[0,540,286,80]]}
];


// symbols:



(lib.Lantuspsd_1 = function() {
	this.spriteSheet = ss["300x600_CDI_Banner_3_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Logo_286x80 = function() {
	this.spriteSheet = ss["300x600_CDI_Banner_3_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whiterect = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AspETIAAolIZTAAIAAIlg");
	this.shape.setTransform(81,27.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,162,55);


(lib.SaveNowbtn1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAdA+IgdhUIAAAAIgaBUIggAAIgrh7IAiAAIAaBWIAAAAIAahWIAhAAIAbBWIAAAAIAZhWIAgAAIgqB7g");
	this.shape.setTransform(131.5,28.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgiA5QgOgIgKgPQgIgOgBgUQABgTAIgPQAKgOAOgIQAQgIASAAQATAAAPAIQAPAIAJAOQAJAPAAATQAAAUgJAOQgJAPgPAIQgPAIgTAAQgSAAgQgIgAgSgfQgJAFgEAJQgEAIAAAJQAAAKAEAJQAEAIAJAFQAIAFAKAAQALAAAIgFQAJgFAEgIQAEgJAAgKQAAgJgEgIQgEgJgJgFQgIgFgLAAQgKAAgIAFg");
	this.shape_1.setTransform(113.4,28.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AApBbIhaiLIAAAAIAACLIggAAIAAi2IAqAAIBYCHIAAAAIAAiHIAiAAIAAC2g");
	this.shape_2.setTransform(95.2,25.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAFBBQgSAAgQgIQgPgIgJgPQgJgPAAgTQAAgTAJgPQAJgOAPgIQAQgIASAAQARAAANAHQANAIAHAPQAIAPAAAVIAAAJIheAAQACANAJAIQAJAIAMAAQAMAAAIgFQAIgEAGgIIAWARQgLANgNAGQgNAGgNAAIgCAAgAAggMQAAgNgJgIQgIgIgPAAQgNAAgIAIQgIAIgCANIA/AAIAAAAg");
	this.shape_3.setTransform(69.8,28.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgPA+Igyh7IAhAAIAhBWIAAAAIAhhWIAgAAIgxB7g");
	this.shape_4.setTransform(55.7,28.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AghA9QgKgEgGgJQgHgIAAgMQAAgPAIgJQAHgHAMgFQAMgEAOgBQAMgBAMAAIAIAAIAAgDQAAgMgIgGQgIgGgMAAQgJAAgJAEQgIADgHAGIgQgQQALgLANgFQAOgEAOAAQATAAALAGQALAGAFAJQAFAJABAJQABAKAAAHIAABGIgcAAIAAgRIgBAAQgHAKgKAGQgKAEgMAAQgLAAgLgEgAAGAHQgHAAgHACQgHACgFAEQgFAEAAAHQAAAFAEAEQADAEAFABQAFACAFAAQAPAAAHgIQAIgHAAgOIAAgGIgGAAIgPAAg");
	this.shape_5.setTransform(41.7,28.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgkBbQgPgGgMgNIAZgYQAGAJAKAFQAKAFAKAAQAHAAAIgDQAGgDAFgFQAFgGABgIQgBgKgGgGQgHgFgJgEIgUgHQgLgDgKgGQgKgFgGgKQgGgJAAgRQAAgSAJgNQAKgMAQgGQAPgGAQAAQAOAAAOAEQAOAFAKAKIgXAZQgGgHgIgEQgJgEgKAAQgGAAgHADQgGACgFAFQgFAGABAIQAAAJAGAFQAGAGAKADIAUAHQALADAKAGQAKAFAGAKQAGAKAAAQQAAAUgJANQgJANgPAGQgQAGgRAAIgCAAQgQAAgPgFg");
	this.shape_6.setTransform(27.4,25.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},3).wait(1));

	// Layer 1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#6B82D9").s().p("AspETIAAolIZTAAIAAIlg");
	this.shape_7.setTransform(81,27.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAdA+IgdhUIAAAAIgaBUIggAAIgrh7IAiAAIAaBWIAAAAIAahWIAhAAIAbBWIAAAAIAZhWIAgAAIgqB7g");
	this.shape_8.setTransform(131.5,28.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgiA5QgOgIgKgPQgIgOgBgUQABgTAIgPQAKgOAOgIQAQgIASAAQATAAAPAIQAPAIAJAOQAJAPAAATQAAAUgJAOQgJAPgPAIQgPAIgTAAQgSAAgQgIgAgSgfQgJAFgEAJQgEAIAAAJQAAAKAEAJQAEAIAJAFQAIAFAKAAQALAAAIgFQAJgFAEgIQAEgJAAgKQAAgJgEgIQgEgJgJgFQgIgFgLAAQgKAAgIAFg");
	this.shape_9.setTransform(113.4,28.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AApBbIhaiLIAAAAIAACLIggAAIAAi2IAqAAIBYCHIAAAAIAAiHIAiAAIAAC2g");
	this.shape_10.setTransform(95.2,25.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAFBBQgSAAgQgIQgPgIgJgPQgJgPAAgTQAAgTAJgPQAJgOAPgIQAQgIASAAQARAAANAHQANAIAHAPQAIAPAAAVIAAAJIheAAQACANAJAIQAJAIAMAAQAMAAAIgFQAIgEAGgIIAWARQgLANgNAGQgNAGgNAAIgCAAgAAggMQAAgNgJgIQgIgIgPAAQgNAAgIAIQgIAIgCANIA/AAIAAAAg");
	this.shape_11.setTransform(69.8,28.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgPA+Igyh7IAhAAIAhBWIAAAAIAhhWIAgAAIgxB7g");
	this.shape_12.setTransform(55.7,28.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AghA9QgKgEgGgJQgHgIAAgMQAAgPAIgJQAHgHAMgFQAMgEAOgBQAMgBAMAAIAIAAIAAgDQAAgMgIgGQgIgGgMAAQgJAAgJAEQgIADgHAGIgQgQQALgLANgFQAOgEAOAAQATAAALAGQALAGAFAJQAFAJABAJQABAKAAAHIAABGIgcAAIAAgRIgBAAQgHAKgKAGQgKAEgMAAQgLAAgLgEgAAGAHQgHAAgHACQgHACgFAEQgFAEAAAHQAAAFAEAEQADAEAFABQAFACAFAAQAPAAAHgIQAIgHAAgOIAAgGIgGAAIgPAAg");
	this.shape_13.setTransform(41.7,28.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgkBbQgPgGgMgNIAZgYQAGAJAKAFQAKAFAKAAQAHAAAIgDQAGgDAFgFQAFgGABgIQgBgKgGgGQgHgFgJgEIgUgHQgLgDgKgGQgKgFgGgKQgGgJAAgRQAAgSAJgNQAKgMAQgGQAPgGAQAAQAOAAAOAEQAOAFAKAKIgXAZQgGgHgIgEQgJgEgKAAQgGAAgHADQgGACgFAFQgFAGABAIQAAAJAGAFQAGAGAKADIAUAHQALADAKAGQAKAFAGAKQAGAKAAAQQAAAUgJANQgJANgPAGQgQAGgRAAIgCAAQgQAAgPgFg");
	this.shape_14.setTransform(27.4,25.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#8BA8E8").s().p("AspETIAAolIZTAAIAAIlg");
	this.shape_15.setTransform(81,27.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7}]}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_15}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,162,55);


(lib.purplerect = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6B82D9").s().p("AspETIAAolIZTAAIAAIlg");
	this.shape.setTransform(81,27.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,162,55);


(lib.Logobtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.298)").s().p("A3RG9IAAtvMAujgAKIAAN5g");
	this.shape.setTransform(127.5,43.5,0.856,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33FF00").s().p("A3RG4IAAtvMAujAAAIAANvg");
	this.shape_1.setTransform(127.3,44,0.854,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.Lantus = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Lantuspsd_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,54,538);


(lib.LantusImagecopy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	mask.setTransform(158,642);

	// Layer 3
	this.instance = new lib.Lantus("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(289,823,1,1,180,0,0,27,269);

	this.instance_1 = new lib.Lantus("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(27,269,1,1,0,0,0,27,269);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bG7IAAt0MAu3AAAIAAN0g");
	this.shape.setTransform(158,642);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.LantusImagecopy3, new cjs.Rectangle(8,342,300,600), null);


(lib.CTABtnAnimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// White box
	this.instance = new lib.whiterect("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-32,-0.1,1,1,0,0,0,81,27.4);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(8).to({_off:false},0).to({alpha:1},5).to({alpha:0},5).to({_off:true},1).wait(1));

	// Save Now
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAdA+IgdhUIAAAAIgaBUIggAAIgrh7IAiAAIAaBWIABAAIAZhWIAgAAIAbBWIABAAIAZhWIAgAAIgqB7g");
	this.shape.setTransform(18.6,1.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AghA5QgPgIgKgPQgJgPAAgTQAAgTAJgOQAKgPAPgIQAPgIASAAQATAAAPAIQAPAIAJAPQAJAOAAATQAAATgJAPQgJAPgPAIQgPAIgTAAQgSAAgPgIgAgTgfQgIAGgEAHQgFAJAAAJQAAAKAFAIQAEAJAIAFQAJAFAKABQALgBAJgFQAHgFAFgJQAEgIAAgKQAAgJgEgJQgFgHgHgGQgJgFgLgBQgKABgJAFg");
	this.shape_1.setTransform(0.5,1.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AApBcIhZiMIgBAAIAACMIghAAIAAi3IAsAAIBXCIIABAAIAAiIIAgAAIAAC3g");
	this.shape_2.setTransform(-17.7,-1.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAFBBQgSAAgQgIQgPgIgJgPQgJgPAAgTQAAgTAJgPQAJgOAPgIQAQgIASAAQARAAANAHQANAIAHAPQAIAPAAAVIAAAJIheAAQACANAJAIQAJAIAMAAQAMAAAIgFQAIgEAGgIIAWARQgLANgNAGQgNAGgNAAIgCAAgAAggMQAAgNgJgIQgIgIgPAAQgNAAgIAIQgIAIgCANIA/AAIAAAAg");
	this.shape_3.setTransform(-43.1,1.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgPA+Igyh7IAhAAIAhBWIAAAAIAhhWIAgAAIgxB7g");
	this.shape_4.setTransform(-57.2,1.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AghA9QgKgEgGgIQgHgJAAgMQAAgPAIgJQAHgHAMgFQAMgEAOgBQAMgCAMABIAIAAIAAgEQAAgLgIgGQgIgGgMAAQgJAAgJADQgIAEgHAGIgQgRQALgKANgEQAOgFAOAAQATAAALAGQALAGAFAJQAFAJABAKQABAJAAAGIAABHIgcAAIAAgRIgBAAQgHALgKAEQgKAFgMAAQgLAAgLgEgAAGAHQgHABgHABQgHACgFAEQgFAEAAAGQAAAHAEADQADAEAFACIAKABQAPAAAHgIQAIgIAAgMIAAgIIgGAAIgPABg");
	this.shape_5.setTransform(-71.2,1.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgjBbQgQgGgLgNIAYgYQAGAJAJAFQALAFALAAQAGAAAHgDQAHgDAGgFQAEgGAAgIQAAgKgGgGQgGgFgKgEIgUgHQgLgDgKgGQgKgFgGgKQgGgJAAgRQAAgSAKgNQAJgMAPgGQAQgGAQAAQAPAAANAEQAOAFALAKIgZAZQgEgHgJgEQgJgEgJAAQgHAAgHADQgGACgFAFQgFAGAAAIQABAJAGAFQAGAGAKADIAUAHQALADAKAGQAKAFAGAKQAGAKAAAQQAAAUgJANQgJANgPAGQgPAGgRAAIgDAAQgQAAgOgFg");
	this.shape_6.setTransform(-85.5,-1.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},13).to({state:[]},6).wait(1));

	// purple rect
	this.instance_1 = new lib.purplerect("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-32,-449.8,1,0.071,0,0,0,81,27.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regY:27.1,scaleY:8.72,y:-215.2},4).to({regY:27.4,scaleY:1,y:-0.1},4).to({startPosition:0},5).to({startPosition:0},5).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-113,-451.8,162,3.9);


// stage content:
(lib._300x600_CDI_Banner_3 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgiAkIAAhHIBEAAIAABHg");
	this.shape.setTransform(264.4,170.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAiB4IAAiTQAAgLgCgIIgDgMQgFgIgNAAQgMAAgLAGQgMAFgJAKIAAClIhAAAIAAjqIA7AAIAAATQAPgKAQgHQAQgHASAAQATAAANAGQANAHAJAKQAIAMAEAPQAFAOAAARIAACeg");
	this.shape_1.setTransform(245.7,161.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgfCkIAAjrIA/AAIAADrgAgfhnIAAg8IA+AAIAAA8g");
	this.shape_2.setTransform(227.7,157.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgfCiIAAlCIA/AAIAAFCg");
	this.shape_3.setTransform(216.6,157.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag5ByQgOgGgIgLQgJgLgFgOQgEgPAAgRIAAifIBAAAIAACXQAAAUAGAHQAEAIAOAAQALAAAMgGQALgGAJgIIAAimIBAAAIAADrIg7AAIAAgVQgPAKgQAIQgPAHgTAAQgSAAgNgGg");
	this.shape_4.setTransform(198.5,162.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgtBvQgLgFgLgJQgLgLgLgPIAsghIAJANIAMALQAGAEAIAEQAHACAIAAIAJAAQAFgCAEgCIAHgGQADgEAAgFQAAgJgJgGIgPgHIgVgJQgZgJgVgOQgWgQAAgiQAAgRAIgMQAFgOAMgJQALgIAOgFQAOgFAQAAQAbAAAUAJQAUAKATAVIgqAkQgHgKgLgIQgLgIgNAAQgHAAgJADQgIADAAALQAAAIALAGQAKAGALAFIAXAHQALAFALAGQAKAFAJAJQAQAUAAAeQAAAfgZATQgXATgnAAQgYAAgYgLg");
	this.shape_5.setTransform(176.5,162);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAiB4IAAiTQAAgLgCgIIgDgMQgFgIgNAAQgMAAgLAGQgMAFgJAKIAAClIhAAAIAAjqIA7AAIAAATQAPgKAQgHQAQgHASAAQATAAANAGQANAHAJAKQAIAMAEAPQAFAOAAARIAACeg");
	this.shape_6.setTransform(155.1,161.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgiCiIAAlCIBEAAIAAFCg");
	this.shape_7.setTransform(137.1,157.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAiB4IAAiTQAAgLgCgIIgDgMQgFgIgNAAQgMAAgLAGQgMAFgJAKIAAClIhAAAIAAjqIA7AAIAAATQAPgKAQgHQAQgHASAAQATAAANAGQANAHAJAKQAIAMAEAPQAFAOAAARIAACeg");
	this.shape_8.setTransform(104.5,161.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhKBYQgcghAAg2QAAg3AcghQAbgiAvAAQAvAAAdAiQAbAhAAA3QAAA2gbAhQgdAigvAAQgvAAgbgigAgUg9QgIAIgEAKQgEAKgBAMIgBAWIABAVQABAMAEALQAEAKAIAHQAIAHAMAAQANAAAIgHQAIgHAEgKQAEgKACgNIABgVQAAgjgKgSQgJgQgVAAQgMAAgIAHg");
	this.shape_9.setTransform(81.6,162);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhKBYQgcghAAg3QAAg2AcghQAbgiAvAAQAvAAAdAiQAbAhAAA2QAAA3gbAhQgdAigvAAQgvAAgbgigAgUg9QgIAIgEAKQgEAKgBAMIgBAVIABAWQABAMAEALQAEAKAIAHQAIAHAMAAQANAAAIgHQAIgHAEgKQAEgKACgNIABgWQAAgigKgSQgJgQgVAAQgMAAgIAHg");
	this.shape_10.setTransform(260.2,41.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAVCdQgaAAgQgOQgQgNAAgdIAAiBIggAAIAAg1IAgAAIAAhLIA+AAIAABLIAtAAIAAA1IgtAAIAAB5QAAAIAEABQAEACAHAAQAHAAAHgCIAQgEIAAA3IgNACIgKABIgLABIgPAAg");
	this.shape_11.setTransform(241.9,38.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhoChIAAk9IA+AAIAAAPQALgJANgFQANgFAPAAQAsAAAaAkQAZAiAAA5QAAAxgbAhQgbAigpAAQgNAAgNgFQgNgGgLgJIAABigAgXhnQgIAFgJAIIAABnQAIAHAJAFQAJAFAKAAQAOAAAIgHQAJgGAFgKQAFgKACgMQACgMAAgLQAAgRgDgNQgDgNgGgJQgLgRgVAAQgMAAgIAEg");
	this.shape_12.setTransform(210.3,45.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag5ByQgOgGgIgLQgJgLgFgOQgEgPAAgRIAAifIBAAAIAACXQAAAUAGAHQAEAIAOAAQALAAAMgGQALgGAJgIIAAimIBAAAIAADrIg7AAIAAgVQgPAKgQAIQgPAHgTAAQgSAAgNgGg");
	this.shape_13.setTransform(185.4,42);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgsBwQgUgKgMgRQgMgRgGgWQgGgWAAgYQAAgXAGgWQAGgXANgQQAMgRAUgKQATgKAaAAQApAAAbAeQANAPAIASQAIATAAAXIAAAdIiHAAIADAVQACAKAFAIQAEAIAIAEQAIAFAMAAQAQAAALgIQALgIAKgNIAvAeQgLAPgKALQgLAJgMAGQgXALgiAAQgZAAgTgKgAAoggQgCgRgJgLQgKgLgSAAQgJAAgGACQgHADgEAGQgFAGgCAHIgEAPIBMAAIAAAAg");
	this.shape_14.setTransform(149,41.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AggB2IhBjrIA/AAIAiCLIAiiLIBAAAIhEDrg");
	this.shape_15.setTransform(128.8,41.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ag6B1QgMgEgJgJQgIgJgFgMQgFgMAAgOQAAgjAagWQATgOAWgGQAVgHAWgFQAIgBALgBIAAgNQAAgNgJgFQgIgHgLABQgRgBgLAJQgKAHgKAOIgqgfQAPgZAYgLQAXgMAcAAQAxAAAVAYQAVAWAAAxIAABuQAAAMACAHQABABAAABQAAAAAAABQAAAAgBAAQAAABAAAAIgCABIAAAKIg5AAIgCgQQgRAKgQAFQgPAFgUAAQgOAAgMgFgAAMAPQgLACgJAEQgLAFgHAHQgHAHAAAMQAAAJAGAGQAFAFAKAAQAMABALgIQAMgGAJgHIAAgqIgUAFg");
	this.shape_16.setTransform(107.5,41.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhACTQgSgJgNgPQgNgPgKgYIA6gZQAFAMAGAJQAGAJAIAHQAIAGAKAEQAKADAMAAQAJAAAJgBQAIgCAIgEQAGgEAEgHQAEgIAAgKQAAgQgQgLQgTgNgYgJQgzgTgZgUQgZgWAAgnQAAgmAegaQAegZAuAAQAlAAAeATQAQAJALAOQAMAPAJAWIhAATQgHgSgMgMQgMgLgVAAIgOABQgHACgGADQgFADgFAGQgDAGAAAIQAAAHAEAGQAEAGAKAFQAVAMAZAJQAlANAdAVQAfAXAAAsQAAAwgfAaQgeAZg2AAQgjAAghgTg");
	this.shape_17.setTransform(83.8,37.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AjeFBIFmqBIBcAAIlnKBgACCEsQgegMgVgXQgXgWgMgeQgNgdABgiQAAghANgcQANgdAWgWQAWgVAdgNQAegLAgAAQAhAAAdALQAdANAXAWQAWAXAMAdQANAeABAhQAABBgxAvQgwAvhBAAQghAAgegNgACXBvQgSASAAAZQABAZARARQATARAYAAQAZAAARgSQARgSABgZQgBgYgRgSQgSgQgYgBQgZAAgSASgAj/gDQgegNgWgWQgVgWgNgdQgMgeAAghQgBghANgdQAOgdAVgWQAXgVAdgNQAdgMAhAAQAhAAAdAMQAeANAWAWQAWAWAMAeQANAdAAAhQAABDgwAuQgvAvhCAAQgigBgdgMgAjrjAQgRASAAAZQAAAaASARQASARAYAAQAZAAASgSQARgTAAgZQAAgYgRgSQgSgRgZAAQgYAAgTASg");
	this.shape_18.setTransform(211,98.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhxEkQgsgdgagtQgagvgKg5QgKg5AAg4QAAg4AKg6QAKg5AaguQAaguAsgdQAtgdBEAAQBFAAAsAdQAtAdAZAuQAbAuAJA5QALA6AAA4QAACUg5BWQg6BWhzAAQhEAAgtgdgAhNieQgZA3AABoQAABpAZA1QAYA1A1AAQA2AAAXg1QAZg1AAhpQAAhogZg3QgXg1g2AAQg1AAgYA1g");
	this.shape_19.setTransform(147.9,98.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AihD5QgggkgQg2QgPg1AAhHQAAilBJheQBJhgB8AAQAtAAAnAOQAoANAlAZIg5BqQgWgVgagOQgbgOgeAAQg9ABgqA3QgZAhgLBCQAagUAfgIQAfgJAfAAQAuAAAlAQQAlAQAaAcQAaAbAOAlQAOAnAAAtQAABbg/A6Qg+A5hiAAQhiAAhBhIgAg5AgQgYASgQAdQADAZAGAYQAGAYAMASQAMAUATAKQATAMAeAAQArAAAWgcQAXgbAAgpQAAgwgZgbQgMgMgSgIQgRgGgYAAQgiAAgZARg");
	this.shape_20.setTransform(96.6,98.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(21));

	// logo btn
	this.logobtn = new lib.Logobtn();
	this.logobtn.parent = this;
	this.logobtn.setTransform(150,300,1,1,0,0,0,149,44);
	new cjs.ButtonHelper(this.logobtn, 0, 1, 2, false, new lib.Logobtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.logobtn).wait(21));

	// Layer 4
	this.instance = new lib.Logo_286x80();
	this.instance.parent = this;
	this.instance.setTransform(6,265,0.857,0.857);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(21));

	// CTA Anim
	this.instance_1 = new lib.CTABtnAnimation("synched",0,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(159,447);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({_off:true},19).wait(1));

	// btn 1
	this.btn1 = new lib.SaveNowbtn1();
	this.btn1.parent = this;
	this.btn1.setTransform(127,446.9,1,1,0,0,0,81,27.4);
	this.btn1._off = true;
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.SaveNowbtn1(), 3);

	this.timeline.addTween(cjs.Tween.get(this.btn1).wait(20).to({_off:false},0).wait(1));

	// 300x600
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#1C2329").s().p("AgZAWIAJgGQAHAIAJAAQAOAAAAgKQAAgHgOgDQgLgDgEgCQgHgEAAgJQAAgJAIgFQAGgFAJAAQAQAAAHALIgKAGQgEgHgJAAQgEAAgEACQgEADAAAEQAAAGAPADQAWAFAAAOQAAAKgIAGQgHAEgLAAQgRAAgIgMg");
	this.shape_21.setTransform(204.3,562.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#1C2329").s().p("AgWAYQgJgJAAgPQAAgOAJgKQAKgJANAAQAOAAAJAJQAIAJAAAPIAAADIg0AAQABAJAGAGQAGAGAIAAQAOAAAHgKIAIAHQgKANgTAAQgOAAgJgKgAgNgSQgGAFgBAIIApAAQgBgIgFgFQgFgFgJAAQgIAAgGAFg");
	this.shape_22.setTransform(197.2,562.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#1C2329").s().p("AgEAlQgDgFAAgLIAAgjIgPAAIAAgJIAPAAIAAgTIAKAAIAAATIATAAIAAAJIgTAAIAAAgQAAAIABACQACAFAHAAQAFAAAEgCIABAKQgGACgHAAQgKAAgEgGg");
	this.shape_23.setTransform(190.4,561.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#1C2329").s().p("AgVAdQgHgFAAgJQAAgOAPgEQAJgEARAAIAEAAIAAgCQAAgOgQAAQgLAAgIAHIgHgHQAKgKAPAAQAcAAAAAbIABAnIgLAAIgBgKQgHALgNAAQgLAAgHgFgAgQAOQAAALAOAAQASAAABgUIAAgEIgLAAQgWAAAAANg");
	this.shape_24.setTransform(183.9,562.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#1C2329").s().p("AAUAxIgagsIgPAAIAAAsIgMAAIAAhiIAZAAQARABAJAEQANAGAAARQAAAVgZAEIAcAtgAgVgFIAKAAQANAAAGgCQAKgDAAgLQAAgQgXgBIgQAAg");
	this.shape_25.setTransform(176.1,560.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#1C2329").s().p("AghAmIAIgJQALALAOAAQAYAAAAgaIAAgJIAAAAQgIANgQAAQgNAAgLgKQgKgIAAgPQAAgQAKgJQAJgJAPAAQARAAAHAMIAAAAIAAgLIALAAIAAA+QAAAkgjAAQgUAAgNgMgAgPggQgHAHAAAKQAAAKAHAGQAHAHAIAAQAMAAAGgIQAGgFAAgKQAAgLgGgGQgIgHgKAAQgJAAgGAHg");
	this.shape_26.setTransform(162.5,564);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1C2329").s().p("AASAhIAAgmQAAgRgPAAQgTAAAAAXIAAAgIgLAAIgBhAIAKAAIABALIAAAAQACgFAGgEQAGgDAHAAQAZAAAAAaIAAAng");
	this.shape_27.setTransform(154.1,562.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#1C2329").s().p("AgFAxIAAhAIAKAAIAABAgAgHgoQAAgJAHAAQAIAAAAAJQAAAHgIABQgHgBAAgHg");
	this.shape_28.setTransform(148.2,560.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#1C2329").s().p("AgiAyIAAhhIALAAIAAAKIABAAQAJgLANAAQAQAAAJAKQAKAJAAAPQAAAOgKAJQgJAKgOAAQgRAAgHgNIgBAAIAAAsgAgQggQgHAIAAAKQAAAKAHAGQAGAHAKAAQAKAAAHgHQAGgGAAgKQAAgKgGgIQgHgGgKAAQgKAAgGAGg");
	this.shape_29.setTransform(142,564);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#1C2329").s().p("AgiAyIAAhhIALAAIAAAKIABAAQAJgLANAAQAQAAAJAKQAKAJAAAPQAAAOgKAJQgJAKgOAAQgRAAgHgNIgBAAIAAAsgAgQggQgHAIAAAKQAAAKAHAGQAGAHAKAAQAKAAAHgHQAGgGAAgKQAAgKgGgIQgHgGgKAAQgKAAgGAGg");
	this.shape_30.setTransform(133.1,564);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#1C2329").s().p("AgEAxIAAhAIAKAAIAABAgAgHgoQAAgJAHAAQAIAAAAAJQAAAHgIABQgHgBAAgHg");
	this.shape_31.setTransform(126.7,560.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#1C2329").s().p("AASA1IAAgoQAAgQgPAAQgUAAABAYIAAAgIgMAAIAAhpIAMAAIAAAxQAGgKANAAQAaAAAAAZIAAApg");
	this.shape_32.setTransform(120.8,560.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#1C2329").s().p("AggAnIAKgJQAGALAPAAQAIAAAGgEQAHgFAAgIQAAgJgGgDQgEgDgPgFQgMgEgFgEQgIgHAAgLQAAgOALgIQAJgHANAAQASAAAKALIgKAJQgFgJgNAAQgIAAgFAEQgHAEAAAJQAAAGAFAEQAEADALAFQAPAEAGAEQAJAHAAANQAAAOgLAIQgKAHgNAAQgWAAgJgNg");
	this.shape_33.setTransform(112.5,560.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#1C2329").s().p("AgFAGQgCgDAAgDQAAgDACgCQADgCACgBQAEABACACQACACAAADQAAADgCADQgDADgDgBQgCABgDgDg");
	this.shape_34.setTransform(102.2,565);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#1C2329").s().p("AgfAnIAJgJQAGALAPAAQAIAAAGgEQAHgFAAgIQAAgJgGgDQgEgDgPgFQgMgEgFgEQgIgHAAgLQAAgOALgIQAJgHAOAAQARAAAKALIgJAJQgGgJgMAAQgJAAgFAEQgHAEAAAJQAAAGAFAEQAEADALAFQAPAEAFAEQAKAHgBANQAAAOgKAIQgJAHgOAAQgVAAgJgNg");
	this.shape_35.setTransform(95.9,560.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#1C2329").s().p("AgFAGQgDgDABgDQgBgDADgCQADgCACgBQADABADACQADACAAADQAAADgDADQgDADgDgBQgCABgDgDg");
	this.shape_36.setTransform(89.8,565);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#1C2329").s().p("AgkAKIAAg8IALAAIAAA7QAAAfAZAAQAaAAAAgfIAAg7IALAAIAAA8QAAASgIALQgKAMgTAAQgkAAAAgpg");
	this.shape_37.setTransform(82.6,560.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#1C2329").s().p("AASAhIgSgyIgQAyIgMAAIgVhBIAMAAIAPAyIARgyIALAAIARAyIAPgyIAMAAIgVBBg");
	this.shape_38.setTransform(67.9,562.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#1C2329").s().p("AgYAZQgKgKAAgPQAAgOAKgKQAKgJAOAAQAPAAAKAJQAKAKAAAOQAAAPgKAKQgKAJgPAAQgOAAgKgJgAgQgQQgGAHAAAJQAAALAGAGQAHAHAJAAQALAAAGgHQAGgGAAgLQAAgJgGgHQgGgHgLAAQgJAAgHAHg");
	this.shape_39.setTransform(58.2,562.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#1C2329").s().p("AgbAxIAAhiIALAAIAABYIAsAAIAAAKg");
	this.shape_40.setTransform(50.8,560.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#1C2329").s().p("AgYAsQgKgKAAgOQAAgPAKgJQAJgKAPAAQAOAAAJALIABAAIAAgyIALAAIAABpIgLAAIAAgLIgBAAQgHANgRAAQgOAAgJgKgAgPACQgHAHAAALQAAAKAHAHQAGAHAJAAQALAAAGgHQAHgHAAgKQAAgLgHgHQgGgGgLAAQgJAAgGAGg");
	this.shape_41.setTransform(201.9,578.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#1C2329").s().p("AgWAYQgJgJAAgPQAAgOAJgKQAKgJANAAQAOAAAJAJQAIAJAAAPIAAADIg0AAQABAJAGAGQAGAGAIAAQANAAAIgKIAIAHQgKANgTAAQgOAAgJgKgAgNgSQgGAFgBAIIApAAQgBgIgFgFQgFgFgJAAQgIAAgGAFg");
	this.shape_42.setTransform(193.5,580.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#1C2329").s().p("AgTAZQgKgKAAgPQAAgOAKgJQAJgKAOAAQAQAAAKAKIgJAIQgHgIgKAAQgKAAgFAHQgGAHAAAJQAAAKAGAHQAHAHAIAAQALAAAGgIIAIAIQgJAKgQAAQgOAAgJgJg");
	this.shape_43.setTransform(186.2,580.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#1C2329").s().p("AgRAhIAAhAIAKAAIAAALQAGgMAPAAIAFAAIgBALIgGgBQgSAAAAAXIAAAgg");
	this.shape_44.setTransform(180.4,580.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#1C2329").s().p("AgcAHIAAgoIALAAIAAAnQAAARAPABQAUAAAAgYIAAghIAKAAIABBBIgKAAIgBgLQgGANgPAAQgZAAAAgbg");
	this.shape_45.setTransform(173.3,580.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#1C2329").s().p("AgYAZQgKgKAAgPQAAgOAKgKQAKgJAOAAQAPAAAKAJQAKAKAAAOQAAAPgKAKQgKAJgPAAQgOAAgKgJgAgPgQQgHAHAAAJQAAALAHAGQAFAHAKAAQALAAAGgHQAGgGAAgLQAAgJgGgHQgGgHgLAAQgKAAgFAHg");
	this.shape_46.setTransform(164.9,580.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#1C2329").s().p("AggAnIAKgJQAHALAOAAQAIAAAGgEQAHgFAAgIQAAgJgGgDQgEgDgPgFQgMgEgFgEQgIgHAAgLQAAgOALgIQAJgHANAAQASAAAKALIgKAJQgFgJgNAAQgUAAAAARQAAAGAFAEQAEADALAFQAPAEAGAEQAJAHAAANQAAAOgLAIQgKAHgNAAQgWAAgJgNg");
	this.shape_47.setTransform(156.4,578.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#1C2329").s().p("AASAhIAAgmQAAgRgPAAQgTAAAAAXIAAAgIgLAAIgBhAIAKAAIABALQAGgMAPAAQAZAAAAAaIAAAng");
	this.shape_48.setTransform(144.1,580.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#1C2329").s().p("AgVAdQgHgFAAgJQAAgOAPgEQAJgEAQAAIAFAAIAAgCQAAgOgRAAQgKAAgIAHIgHgHQAKgKAPAAQAcAAAAAbIAAAbIABAMIgLAAIgBgKQgHALgOAAQgKAAgHgFgAgQAOQAAALAOAAQAIAAAGgGQAEgFABgJIAAgEIgLAAQgWAAAAANg");
	this.shape_49.setTransform(136.1,580.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#1C2329").s().p("AgEAxIAAhAIAJAAIAABAgAgHgoQAAgJAHAAQAIAAAAAJQAAAHgIABQgHgBAAgHg");
	this.shape_50.setTransform(130.6,578.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#1C2329").s().p("AgYAsQgKgKAAgOQAAgPAKgJQAJgKAPAAQAOAAAJALIABAAIAAgyIALAAIAABpIgLAAIAAgLIgBAAQgHANgRAAQgOAAgJgKgAgPACQgHAHAAALQAAAKAHAHQAGAHAJAAQALAAAGgHQAHgHAAgKQAAgLgHgHQgGgGgLAAQgJAAgGAGg");
	this.shape_51.setTransform(124.1,578.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#1C2329").s().p("AgVAdQgHgFAAgJQAAgWApAAIAEAAIAAgCQAAgOgQAAQgLAAgIAHIgHgHQAKgKAPAAQAcAAAAAbIABAnIgLAAIAAgKIgBAAQgHALgNAAQgLAAgHgFgAgQAOQAAALAOAAQAJAAAFgGQAFgFAAgJIAAgEIgLAAQgWAAAAANg");
	this.shape_52.setTransform(115.9,580.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#1C2329").s().p("AASAhIAAgmQAAgRgPAAQgTAAAAAXIAAAgIgLAAIgBhAIALAAIAAALIAAAAQAGgMAPAAQAZAAAAAaIAAAng");
	this.shape_53.setTransform(108.1,580.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#1C2329").s().p("AgVAdQgHgFAAgJQAAgWApAAIAEAAIAAgCQAAgOgQAAQgLAAgIAHIgHgHQAKgKAPAAQAcAAAAAbIABAnIgLAAIAAgKIgBAAQgHALgNAAQgLAAgHgFgAgQAOQAAALAOAAQAJAAAFgGQAFgFAAgJIAAgEIgLAAQgWAAAAANg");
	this.shape_54.setTransform(100.1,580.4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#1C2329").s().p("AgcAmQgPgPAAgXQAAgVAOgPQAOgPAWAAQAWAAANAPIgLAIQgIgMgQAAQgPAAgLAMQgLAMAAAQQgBARALAMQALAMAQAAQARAAALgNIAJAGQgNASgYAAQgVAAgOgOg");
	this.shape_55.setTransform(91.5,578.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#1C2329").s().p("AgiAxIA+hmIAIAEIg9BngAALAsQgHgHAAgLQAAgJAHgIQAHgHAKAAQALAAAHAHQAHAIAAAJQAAALgHAHQgHAHgLAAQgKAAgHgHgAATAQQgEAFgBAFQABAHAEAEQAEAEAFAAQAGAAAFgEQAEgEAAgHQAAgFgEgFQgFgDgGAAQgFAAgEADgAgtgJQgHgGAAgLQAAgKAHgHQAIgIAKABQAKgBAHAIQAHAHAAAKQAAALgHAGQgHAHgKAAQgKAAgIgHgAglgkQgFAFAAAFQAAAGAFAFQAEADAGAAQAFAAAFgDQAEgFAAgGQAAgFgEgFQgFgEgFAAQgGAAgEAEg");
	this.shape_56.setTransform(76,578.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#1C2329").s().p("AghAAQAAgyAhAAQAhAAABAyQgBAzghAAQghAAAAgzgAgVAAQAAApAVAAQAWAAAAgpQAAgogWAAQgVAAAAAog");
	this.shape_57.setTransform(65.9,578.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#1C2329").s().p("AgaAiQgGgNAAgVQAAgUAGgNQAJgRARAAQAiAAgBAyQABAzgiAAQgRAAgJgRgAgVAAQABApAUAAQAWAAAAgpQAAgogWAAQgUAAgBAog");
	this.shape_58.setTransform(57.8,578.7);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#1C2329").s().p("AAHAxIAAhSIgBAAIgQAOIgHgIIAZgWIALAAIAABig");
	this.shape_59.setTransform(49,578.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvgEgXRAuuMAujAAAMAAAhdbMgujAAAg");
	this.shape_60.setTransform(150.1,300.1);

	this.text = new cjs.Text("", "12px 'AvenirLTStd-Heavy'");
	this.text.lineHeight = 19;
	this.text.parent = this;
	this.text.setTransform(21.6,101.4);

	this.instance_2 = new lib.LantusImagecopy3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(150.1,204.1,1,1,0,0,0,158,546);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#6ACADA","#5DBBD2"],[0,1],0,300,0,-300).s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_61.setTransform(150.1,300.1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#5DBBD2").s().p("EgMfAmcMAAAhM3IY/AAMAAABM3g");
	this.shape_62.setTransform(80.1,246.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_62},{t:this.shape_61},{t:this.instance_2},{t:this.text},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21}]}).wait(21));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(142.1,-41.9,323.3,1092);
// library properties:
lib.properties = {
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/300x600_CDI_Banner_3_atlas_.png?1485380188926", id:"300x600_CDI_Banner_3_atlas_"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;